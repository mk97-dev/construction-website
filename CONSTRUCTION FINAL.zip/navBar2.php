<!Doctype html>
<html>
<head>
        <title>Online Library Management</title>
        <link rel="stylesheet" type="text/css" href="navBarStyle.css">
        <meta charset="utf-8">
        <meta name="viewport" content="widthe-device-width, initial-scale=1">
        </head>


        <body>
    
      
        <header>
                <div class="logo">
                    
                    <h1 style="color: white;font-size: 30px;">Online Library Management System &nbsp &nbsp</h1>
                </div>
                <nav class="menuList">
                    <ul>
                        <li><a href="index.php">Home</a></li>
                        <li><a href="bookHtml.php">Books</a></li>
                        <li><a href="addBookHtml.php">Add-Books</a></li>
                        <li><a href="feedback.php">Feedback</a></li>
                    </ul>
                </nav>
                

            </header>
                
            </body>
</html>
