<!Doctype html>
<html>
<head>
        <title>Online Library Management</title>
        <link rel="stylesheet" type="text/css" href="style.css">
        <meta charset="utf-8">
        <meta name="viewport" content="widthe-device-width, initial-scale=1">
        </head>


        <body>
    
      
        <header>
                <div class="logo">
                    
                    <h1 style="color: white;font-size: 30px;">Construction Management &nbsp &nbsp</h1>
                </div>
               

            </header>
                
            </body>
</html>
